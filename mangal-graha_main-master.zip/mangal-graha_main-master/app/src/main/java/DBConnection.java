import android.os.AsyncTask;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection extends AsyncTask<Void, Void, Connection> {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mangalgraha";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    private ConnectionCallback callback;

    public DBConnection(ConnectionCallback callback) {
        this.callback = callback;
    }

    @Override
    protected Connection doInBackground(Void... params) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            // You might want to log the exception or handle it differently
            return null;
        }
    }

    @Override
    protected void onPostExecute(Connection connection) {
        super.onPostExecute(connection);
        if (callback != null) {
            callback.onConnectionReady(connection);
        }
    }

    public interface ConnectionCallback {
        void onConnectionReady(Connection connection);
    }
}
