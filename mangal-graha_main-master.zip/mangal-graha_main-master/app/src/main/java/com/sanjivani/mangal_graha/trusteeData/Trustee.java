package com.sanjivani.mangal_graha.trusteeData;

public class Trustee {
    private int photo;
    private String name;
    private String position;

    public Trustee(int photo, String name, String position) {
        this.photo = photo;
        this.name = name;
        this.position = position;
    }

    public int getPhoto() {
        return photo;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }
}

