package com.sanjivani.mangal_graha.trusteeData;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sanjivani.mangal_graha.R;

import java.util.List;

public class TrusteeAdapter extends RecyclerView.Adapter<TrusteeAdapter.TrusteeViewHolder> {

    private List<Trustee> trusteeList;

    public TrusteeAdapter(List<Trustee> trusteeList) {
        this.trusteeList = trusteeList;
    }

    @NonNull
    @Override
    public TrusteeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_trustee, parent, false);
        return new TrusteeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrusteeViewHolder holder, int position) {
        Trustee trustee = trusteeList.get(position);

        holder.imageView.setImageResource(trustee.getPhoto());
        holder.textName.setText(trustee.getName());
        holder.textPosition.setText(trustee.getPosition());
    }

    @Override
    public int getItemCount() {
        return trusteeList.size();
    }

    static class TrusteeViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textName, textPosition;

        TrusteeViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textName = itemView.findViewById(R.id.textName);
            textPosition = itemView.findViewById(R.id.textPosition);
        }
    }
}

