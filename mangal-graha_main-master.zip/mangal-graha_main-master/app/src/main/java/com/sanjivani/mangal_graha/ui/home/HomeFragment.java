package com.sanjivani.mangal_graha.ui.home;

import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.sanjivani.mangal_graha.AbhishekForm;
import com.sanjivani.mangal_graha.R;
import com.sanjivani.mangal_graha.databinding.FragmentHomeBinding;
import com.sanjivani.mangal_graha.webViewForm;

public class HomeFragment extends Fragment {

    private Button abhishekregistration;
    private FragmentHomeBinding binding;
    private WebView webView;
    ImageView gifImageView;
    SwipeRefreshLayout mySwipeRefreshLayout;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Find the ImageView in your layout file
        gifImageView = root.findViewById(R.id.imageView2); // Replace with your ImageView ID

        // Find the SwipeRefreshLayout in your layout file
        mySwipeRefreshLayout = root.findViewById(R.id.swiperefresh); // Replace with your SwipeRefreshLayout ID


        // Load the GIF into the ImageView using Glide
        // Replace with the URL or local path of your GIF
        Glide.with(requireContext())
                .asGif()
                .load(R.raw.slideshow)
                .placeholder(R.drawable.image1)
                .into(gifImageView);

        // Abhishek Registration Button and functionality
        abhishekregistration = root.findViewById(R.id.abhishekregbtn);

        abhishekregistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), webViewForm.class);
                startActivity(intent);
            }
        });

        mySwipeRefreshLayout.setOnRefreshListener(() -> {


                    // This method performs the actual data-refresh operation and calls
                    // setRefreshing(false) when it finishes.
                    myUpdateOperation();
                }
        );
        // WebView setup
        webView = root.findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Enable desktop view
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);

        // WebView client to open links within the WebView
        webView.setWebViewClient(new WebViewClient());

        // WebView chrome client for handling progress and alert dialogs
        webView.setWebChromeClient(new WebChromeClient());

        // Load the desired URL
        webView.loadUrl("https://mangalgrahsevasanstha.org.in/schedule.html");

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void myUpdateOperation(){
        // Load the desired URL
        webView.reload();
        // Hide the refreshing indicator

        mySwipeRefreshLayout.setRefreshing(true);
        new Handler().postDelayed(() -> {
            // Stop the refreshing indicator
            mySwipeRefreshLayout.setRefreshing(false);
        }, 2000);

    }
}
