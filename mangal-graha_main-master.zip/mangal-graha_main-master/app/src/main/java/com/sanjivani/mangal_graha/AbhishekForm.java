package com.sanjivani.mangal_graha;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AbhishekForm extends Activity {

    private EditText nameEditText;
    private Calendar calendar;
    private SwitchCompat partnerSelector;
    private TextView partnerNameTextView, partnerBirthDateTextView;
    private EditText partnerNameEditText;

    private EditText phoneEditText;
    private EditText emailEditText;
    private EditText addressEditText;
    private EditText cityEditText;
    private EditText stateEditText;
    private Spinner countrySpinner;
    private Spinner genderSpinner;
    private TextInputEditText datePicker,birthdatepicker,partnerbirthdatepicker;
    private Spinner batchTimeSpinner;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_reg_form);
        partnerBirthDateTextView= findViewById(R.id.partnerdatetxt);
        partnerNameTextView = findViewById(R.id.partnerNametxt);
        partnerSelector = findViewById(R.id.partnerSelector);
        nameEditText = findViewById(R.id.nameed);
        phoneEditText = findViewById(R.id.phoneed);
        emailEditText = findViewById(R.id.emailed);
        addressEditText = findViewById(R.id.addressed);
        cityEditText = findViewById(R.id.cityed);
        stateEditText = findViewById(R.id.stateed);
        countrySpinner = findViewById(R.id.countrySpinner);
        genderSpinner = findViewById(R.id.genderSpinner);
        datePicker = findViewById(R.id.datePicker);
        batchTimeSpinner = findViewById(R.id.batchtimeselect);
        submitButton = findViewById(R.id.submitbtn);
        calendar = Calendar.getInstance();

        partnerNameEditText = findViewById(R.id.partnerName);
        birthdatepicker = findViewById(R.id.birthDatePicker);
        partnerbirthdatepicker = findViewById(R.id.partnerDatePicker);



        // Set up date picker
        datePicker.setOnClickListener(this::showDatePickerDialog);
        birthdatepicker.setOnClickListener(v -> showDatePickerDialogForBirthdates(v, birthdatepicker));
        partnerbirthdatepicker.setOnClickListener(v -> showDatePickerDialogForBirthdates(v, partnerbirthdatepicker));

        partnerNameTextView.setVisibility(View.GONE);
        partnerBirthDateTextView.setVisibility(View.GONE);
        partnerNameEditText.setVisibility(View.GONE);
        partnerbirthdatepicker.setVisibility(View.GONE);

        partnerSelector.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                partnerNameTextView.setVisibility(View.VISIBLE);
                partnerBirthDateTextView.setVisibility(View.VISIBLE);
                partnerNameEditText.setVisibility(View.VISIBLE);
                partnerbirthdatepicker.setVisibility(View.VISIBLE);
            } else {
                partnerNameTextView.setVisibility(View.GONE);
                partnerBirthDateTextView.setVisibility(View.GONE);
                partnerNameEditText.setVisibility(View.GONE);
                partnerbirthdatepicker.setVisibility(View.GONE);
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generateReceipt();
            }
        });
    }

    private void showDatePickerDialogForBirthdates(View view, final TextInputEditText editText) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String selectedDate = formatDate(year, month, dayOfMonth);
                        editText.setText(selectedDate);
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        DatePicker datePicker = datePickerDialog.getDatePicker();
        int headerId = Resources.getSystem().getIdentifier("date_picker_header", "id", "android");
        View headerView = datePicker.findViewById(headerId);
        if (headerView != null) {
            headerView.setBackgroundColor(getResources().getColor(R.color.red)); // Set your desired color
        }

        datePickerDialog.show();
    }

    private void generateReceipt() {
        // Get user input
        String name = nameEditText.getText().toString();
        String phone = phoneEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String address = addressEditText.getText().toString();
        String city = cityEditText.getText().toString();
        String state = stateEditText.getText().toString();
        String country = countrySpinner.getSelectedItem().toString();
        String gender = genderSpinner.getSelectedItem().toString();

        // Convert DatePicker values to a Date object
        String[] dateParts = datePicker.getText().toString().split("-");
        if (dateParts.length == 3) {
            String month = dateParts[1].trim();
            String day = dateParts[2].trim();
            String year = dateParts[0].trim();
            String selectedDate = formatDate(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));

            String batchTime = batchTimeSpinner.getSelectedItem().toString();

            // Dummy form data
            Map<String, String> formData = new HashMap<>();
            formData.put("Name", name);
            formData.put("Date of Birth", "");  // You may need to add a DatePicker for Date of Birth
            formData.put("Phone Number", phone);
            formData.put("Address", address);
            formData.put("State", state);
            formData.put("City", city);
            formData.put("Country", country);
            formData.put("Gender", gender);
            formData.put("Selected Date", selectedDate);
            formData.put("Abhishek Type", "");  // You may need to add a field for Abhishek Type
            formData.put("Batch Time", batchTime);

            displayUserData(formData);
            saveAsPdf(formData);
        } else {
            Toast.makeText(this, "Invalid date format", Toast.LENGTH_SHORT).show();
            // Handle the case where the date format is unexpected
            // You may want to display an error message or log a warning
        }
    }

    private String formatDate(int year, int month, int day) {
        // Adjust month because Calendar.MONTH is zero-based
        Calendar calendar = new GregorianCalendar(year, month - 1, day);

        // Create a SimpleDateFormat pattern for the desired date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        // Format the date and return the result
        return dateFormat.format(calendar.getTime());
    }


    public void showDatePickerDialog(View v) {
        // Set up date picker
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        // Set the minimum selectable date to the current date
        Calendar minDate = Calendar.getInstance();

        // Set the maximum selectable date to the current date plus three days
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.DAY_OF_MONTH, 3);

        datePickerDialog.getDatePicker().setMinDate(minDate.getTimeInMillis());
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());

        // Customize the header background color
        DatePicker datePicker = datePickerDialog.getDatePicker();
        int headerId = Resources.getSystem().getIdentifier("date_picker_header", "id", "android");
        View headerView = datePicker.findViewById(headerId);
        if (headerView != null) {
            headerView.setBackgroundColor(getResources().getColor(R.color.red)); // Set your desired color
        }

        datePickerDialog.show();
    }


    private void updateEditTextDate() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        datePicker.setText(sdf.format(calendar.getTime()));
    }

    private DatePickerDialog.OnDateSetListener dateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateEditTextDate();
                }
            };
    private String getUserInformation(Map<String, String> formData) {
        // Return user information in a formatted string
        // Modify this method according to your needs
        StringBuilder userInfo = new StringBuilder();
        for (Map.Entry<String, String> entry : formData.entrySet()) {
            userInfo.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }
        return userInfo.toString();
    }

    private String generateQRCodeData(Map<String, String> formData) {
        // Generate QR code data from user information
        StringBuilder data = new StringBuilder();
        for (Map.Entry<String, String> entry : formData.entrySet()) {
            data.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }
        return data.toString();
    }

    private void saveAsPdf(Map<String, String> formData) {
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(720, 1080, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        android.graphics.Canvas canvas = page.getCanvas();

        // Draw QR code image on the PDF
        Bitmap qrImage = generateQRCode(formData);
        canvas.drawBitmap(qrImage, 10, 50, null);

        // Draw user information and QR code data on the PDF
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setTextSize(12);

        float x = 10;
        float y = 300;

        // Draw user information in a tabular format
        for (Map.Entry<String, String> entry : formData.entrySet()) {
            String line = entry.getKey() + ": " + entry.getValue();
            canvas.drawText(line, x, y, paint);
            y += paint.descent() - paint.ascent();
        }

        // Move to the next line
        y += 20;

        // Draw QR code data
        String qrCodeData = generateQRCodeData(formData);
        String[] qrCodeLines = qrCodeData.split("\n");
        canvas.drawText("QR Code Data:", x, y, paint);
        y += paint.descent() - paint.ascent();
        for (String line : qrCodeLines) {
            canvas.drawText(line, x, y, paint);
            y += paint.descent() - paint.ascent();
        }

        // Add image watermark to the bottom right corner
        Bitmap watermark = BitmapFactory.decodeResource(getResources(), R.drawable.watermark);
        int watermarkWidth = 100;
        int watermarkHeight = 50;
        canvas.drawBitmap(watermark, pageInfo.getPageWidth() - watermarkWidth - 10, pageInfo.getPageHeight() - watermarkHeight - 10, null);

        pdfDocument.finishPage(page);

        // Save PDF to external storage
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Receipts");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String pdfFileName = "Receipt_" + timeStamp + ".pdf";
        File file = new File(directory, pdfFileName);

        try {
            pdfDocument.writeTo(new FileOutputStream(file));
            Toast.makeText(this, "Receipt saved to: " + file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving receipt.", Toast.LENGTH_SHORT).show();
        } finally {
            pdfDocument.close();
        }
    }

    private Bitmap generateQRCode(Map<String, String> formData) {
        StringBuilder data = new StringBuilder();
        for (Map.Entry<String, String> entry : formData.entrySet()) {
            data.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix;
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            bitMatrix = qrCodeWriter.encode(data.toString(), BarcodeFormat.QR_CODE, 200, 200, hints);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }

        Bitmap qrImage = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565);
        for (int x = 0; x < 200; x++) {
            for (int y = 0; y < 200; y++) {
                qrImage.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }

        return qrImage;
    }

    private void displayUserData(Map<String, String> formData) {
        // Display user information
        // You can customize the user interface for displaying information based on your layout
        // For simplicity, let's assume you have a TextView with id "userDataTextView" in your layout
        StringBuilder userDataText = new StringBuilder("User Information:\n");
        for (Map.Entry<String, String> entry : formData.entrySet()) {
            userDataText.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        // Display QR code image
//        ImageView imageView = findViewById(R.id.imageView);
//        Bitmap qrImage = generateQRCode(formData);
//        imageView.setImageBitmap(qrImage);
//
//        // Display user information text
//        TextView userDataTextView = findViewById(R.id.userDataTextView);
//        userDataTextView.setText(userDataText.toString());
    }

}
