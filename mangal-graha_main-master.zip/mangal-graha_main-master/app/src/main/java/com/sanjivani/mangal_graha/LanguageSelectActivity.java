package com.sanjivani.mangal_graha;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LanguageSelectActivity extends AppCompatActivity implements View.OnClickListener {

    Button hindi,english,marathi;
    private static final String PREF_SELECTED_LANGUAGE = "selected_language";
    private static final String LANG_ENGLISH = "en";
    private static final String LANG_HINDI = "hi";
    private static final String LANG_MARATHI = "mr";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.language_select_tab);

        hindi = findViewById(R.id.Hindi);
        english = findViewById(R.id.English);
        marathi = findViewById(R.id.Marathi);

        hindi.setOnClickListener(this);
        english.setOnClickListener(this);
        marathi.setOnClickListener(this);


    }


    private void saveLanguage(String language) {
        SharedPreferences preferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(PREF_SELECTED_LANGUAGE, language);
        editor.apply();
    }
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.Hindi) {
            saveLanguage(LANG_HINDI);
            startActivity(new Intent(LanguageSelectActivity.this, MainActivity.class));
            finish();
        } else if (view.getId() == R.id.English) {
            saveLanguage(LANG_ENGLISH);
            startActivity(new Intent(LanguageSelectActivity.this, MainActivity.class));
            finish();
        } else if (view.getId() == R.id.Marathi) {
            saveLanguage(LANG_MARATHI);
            startActivity(new Intent(LanguageSelectActivity.this, MainActivity.class));
            finish();
        }

    }
}
