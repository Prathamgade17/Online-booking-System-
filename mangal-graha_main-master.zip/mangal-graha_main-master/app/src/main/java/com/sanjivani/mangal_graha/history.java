package com.sanjivani.mangal_graha;

import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.VideoView;

public class history extends Fragment {

    private SwipeRefreshLayout mySwipeRefreshLayout;
    private WebView webView;
    private ProgressBar progressBar;
    private WebSettings webSettings;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root=inflater.inflate(R.layout.fragment_history, container, false);
        mySwipeRefreshLayout = root.findViewById(R.id.swiperefresh);
        webView = root.findViewById(R.id.webView);
        progressBar = root.findViewById(R.id.progressBar);

        webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3");
        webView.setWebViewClient(new MyWebViewClient());

        // Set up WebChromeClient to handle progress updates
        webView.setWebChromeClient(new MyWebChromeClient());

        mySwipeRefreshLayout.setOnRefreshListener(() -> {

            // This method performs the actual data-refresh operation and calls
            // setRefreshing(false) when it finishes.
            myUpdateOperation();
        });


        webView.getSettings().setJavaScriptEnabled(true);

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://marathi.webdunia.com/article/religious-places-marathi/mangalgraha-mandir-amalner-jalgaon-information-marathi-122112100033_1.html");
        return root;



}
    private void myUpdateOperation() {

        webView.reload();
        mySwipeRefreshLayout.setRefreshing(false);
        new Handler().postDelayed(() ->
                        mySwipeRefreshLayout.setRefreshing(false),
                2000);
    }

private class MyWebViewClient extends WebViewClient {
    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        // Show loading message or progress indicator
        progressBar.setVisibility(ProgressBar.VISIBLE);
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        // Hide loading message or progress indicator
        progressBar.setVisibility(ProgressBar.GONE);
    }

    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        // Handle error situations, you can show an error message here
        // For example, you can display a custom error page or message.
        // To avoid the black screen, you can hide the WebView or show a message.
        progressBar.setVisibility(ProgressBar.GONE);
    }
}

private class MyWebChromeClient extends WebChromeClient {
    @Override
    public void onProgressChanged(WebView view, int newProgress) {
        // Update the progress of the ProgressBar
        progressBar.setProgress(newProgress);
    }
}

}
