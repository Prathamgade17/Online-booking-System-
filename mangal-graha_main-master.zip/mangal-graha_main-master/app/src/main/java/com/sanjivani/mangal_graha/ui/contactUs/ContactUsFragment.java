package com.sanjivani.mangal_graha.ui.contactUs;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.sanjivani.mangal_graha.R;
import com.sanjivani.mangal_graha.databinding.FragmentContactusBinding;
import com.sanjivani.mangal_graha.ui.contactUs.ContactUsViewModel;

public class ContactUsFragment extends Fragment {

    private FragmentContactusBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ContactUsViewModel galleryViewModel =
                new ViewModelProvider(this).get(ContactUsViewModel.class);

        binding = FragmentContactusBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        WebView webView = root.findViewById(R.id.map_id);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        String location = "21.0424154,75.0782057";
        String html = "<iframe " +
                "width=\"100%\" " +
                "height=\"100%\" " +
                "frameborder=\"0\" " +
                "scrolling=\"no\" " +
                "marginheight=\"0\" " +
                "marginwidth=\"0\" " +
                "src=\"https://maps.google.com/maps?q=" + location + "&output=embed\"></iframe>";

        // Load the HTML string into the WebView
        webView.loadData(html, "text/html", "utf-8");

        Button callButton1 = root.findViewById(R.id.callButton1);
        Button callButton2 = root.findViewById(R.id.callButton2);
        Button callButton3 = root.findViewById(R.id.callButton3);
        Button emailButton = root.findViewById(R.id.emailButton);

        callButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initiateCall("8348606060");
            }
        });

        callButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initiateCall("8348707070");
            }
        });

        callButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initiateCall("8348808080");
            }
        });

        emailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }
        });

        Button subscribeButton = root.findViewById(R.id.subscribeButton);
        subscribeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subscribeToYouTube();
            }
        });

        return root;
    }

    private void sendEmail() {
        // Replace "recipient@example.com" with the actual recipient email address
        String recipientEmail = "mangalgrahamandir@gmail.coms";

        // Create an Intent to send an email
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + recipientEmail));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject"); // Optional subject
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Body"); // Optional email body

        // Start the email client activity
        startActivity(Intent.createChooser(emailIntent, "Send Email"));
    }

    private void initiateCall(String phoneNumber) {
        // Create an Intent to initiate a phone call
        Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
        // Start the phone call activity
        startActivity(dialIntent);
    }
    private void subscribeToYouTube() {
        // Replace "YOUR_YOUTUBE_CHANNEL_ID" with your actual YouTube channel ID

        // Create an Intent to open the YouTube app or a browser with the subscription link
        Intent youtubeIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/@mangalgrahamandir"));

        // Start the YouTube app or a browser activity
        startActivity(youtubeIntent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
