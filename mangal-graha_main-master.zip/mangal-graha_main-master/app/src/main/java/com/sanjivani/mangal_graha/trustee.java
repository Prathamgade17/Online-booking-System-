package com.sanjivani.mangal_graha;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sanjivani.mangal_graha.trusteeData.Trustee;
import com.sanjivani.mangal_graha.trusteeData.TrusteeAdapter;

import java.util.ArrayList;
import java.util.List;

public class trustee extends Fragment {

    private List<Trustee> trusteeList;
    private TrusteeAdapter trusteeAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_trustee, container, false);

        // Initialize RecyclerView
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Initialize data (you can fetch this from a database)
        initializeData();

        // Initialize and set the adapter
        trusteeAdapter = new TrusteeAdapter(trusteeList);
        recyclerView.setAdapter(trusteeAdapter);

        return view;
    }

    private void initializeData() {
        // Add sample trustee data (replace with your database fetch logic)
        trusteeList = new ArrayList<>();
        trusteeList.add(new Trustee(R.drawable.d, "Shri.Digambhar Vitthal Mahale", "President"));
        trusteeList.add(new Trustee(R.drawable.suresh2, "Shri.Suresh Nilkanth Patil", "Vice-President"));
        trusteeList.add(new Trustee(R.drawable.suresh, "Shri.Suresh Bhagwan Baviskar", "Secretary"));
        trusteeList.add(new Trustee(R.drawable.dilip, "Shri. Dilip Atmaram Bahiram", "Joint- Secretary"));
        trusteeList.add(new Trustee(R.drawable.girish, "Shri. Girish Vishwanath Kulkarni", "Treasurer"));
        trusteeList.add(new Trustee(R.drawable.anil, "Shri. Anil Shridharrao Ahirrao", "Trustee"));
        trusteeList.add(new Trustee(R.drawable.jayshree, "Smt. Jayshree Atmaram Sabe", "Trustee"));
        trusteeList.add(new Trustee(R.drawable.dangaldas, "Shri Dangaldas Aadhar Sonawane", "Trustee"));
        // Add more trustee data as needed
    }
}
