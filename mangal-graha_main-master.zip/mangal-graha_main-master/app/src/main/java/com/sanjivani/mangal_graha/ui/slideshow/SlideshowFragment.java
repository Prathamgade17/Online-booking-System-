package com.sanjivani.mangal_graha.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.sanjivani.mangal_graha.R;
import com.sanjivani.mangal_graha.VPadapter;
import com.sanjivani.mangal_graha.accommodation;
import com.sanjivani.mangal_graha.history;
import com.sanjivani.mangal_graha.trustee;

public class SlideshowFragment extends Fragment {

    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private VPadapter vPadapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        tabLayout = root.findViewById(R.id.tabLayout);
        viewPager = root.findViewById(R.id.view_pager);

        // Initialize the adapter
        vPadapter = new VPadapter(requireActivity());

        // Add fragments to the adapter
        vPadapter.addFragment(new history());
        vPadapter.addFragment(new accommodation());
        vPadapter.addFragment(new trustee());


        // Set the adapter to the ViewPager2
        viewPager.setAdapter(vPadapter);

        // Connect the TabLayout with the ViewPager2
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    // Set tab titles here (if needed)
                    switch (position) {
                        case 0:
                            tab.setText(R.string.history);
                            break;
                        case 1:
                            tab.setText(R.string.accommodation);
                            break;
                        case 2:
                            tab.setText(R.string.trustee);
                            break;
                    }
                }
        ).attach();

        return root;
    }
}
