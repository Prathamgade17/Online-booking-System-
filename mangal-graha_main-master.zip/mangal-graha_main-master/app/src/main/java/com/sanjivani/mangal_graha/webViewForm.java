package com.sanjivani.mangal_graha;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class webViewForm extends AppCompatActivity {

    private WebView webView;
    private String filename;
    private SwipeRefreshLayout mySwipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view_form);
        webView = findViewById(R.id.webView);
        setUpWebViewSettings();
        setUpWebChromeClient();
        setUpDownloadListener();
        webView.loadUrl("https://mangalgrahsevasanstha.org.in/form.php");
        mySwipeRefreshLayout = findViewById(R.id.swiperefresh);

        // This method performs the actual data-refresh operation and calls
        // setRefreshing(false) when it finishes.
        mySwipeRefreshLayout.setOnRefreshListener(this::myUpdateOperation);
    }

    private void myUpdateOperation() {
        webView.reload();
        mySwipeRefreshLayout.setRefreshing(false);

        new Handler().postDelayed(() ->
                        mySwipeRefreshLayout.setRefreshing(false),
                2000);
    }

    private void setUpWebViewSettings() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(this, "Android");
        webView.setWebViewClient(new WebViewClient());
    }
    private void showCustomDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog, null);
        builder.setView(dialogView);
        TextView dialogMessage = dialogView.findViewById(R.id.dialog_message);
        Button dialogButton = dialogView.findViewById(R.id.dialog_button);

        dialogMessage.setText(message);

        final AlertDialog alertDialog = builder.create();
        alertDialog.show();

        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }
    private void setUpWebChromeClient() {
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                // Handle JavaScript alerts
                showCustomDialog(message);
                result.confirm(); // This is important to dismiss the alert
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                // Handle JavaScript confirmations
                showCustomDialog(message);
                result.confirm(); // This is important to dismiss the confirmation
                return true;
            }
        });
    }

    private void setUpDownloadListener() {
        // Check if the required permissions are granted
        if (ContextCompat.checkSelfPermission(webViewForm.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            webView.setDownloadListener(new DownloadListener() {
                @Override
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    //hash the url.substring after the last "/"
                    String hashedFileName = String.valueOf(url.substring(url.lastIndexOf("/") + 1).hashCode());
                    filename = hashedFileName + ".pdf";
                    // Check if the URL starts with "blob:"
                    if (url.startsWith("blob:")) {
                        // Handle blob URLs separately

                        downloadBlobPdf(url);
                    } else {

                        // Normal download handling for non-blob URLs
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                        request.setMimeType(mimetype);
                        String cookies = CookieManager.getInstance().getCookie(url);
                        request.addRequestHeader("cookie", cookies);
                        request.addRequestHeader("User-Agent", userAgent);
                        request.setDescription("Downloading file...");
                        request.setTitle(filename);
                        request.allowScanningByMediaScanner();
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
                        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                        dm.enqueue(request);
                        Toast.makeText(webViewForm.this, "Downloading File", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // Method to handle downloading PDF from a blob URL
    private void downloadBlobPdf(String blobUrl) {
        // Extract blob content from WebView
        webView.evaluateJavascript(
                "(function() { " +
                        "    fetch('" + blobUrl + "')" +
                        "    .then(response => response.blob())" +
                        "    .then(blob => {" +
                        "        var reader = new FileReader();" +
                        "        reader.onload = function() {" +
                        "            Android.saveBlobPdf(reader.result);" + // Pass blob content to Android method
                        "        };" +
                        "        reader.readAsDataURL(blob);" +
                        "    });" +
                        "})();",
                null
        );
    }

    // Method to save blob content received from WebView
    @android.webkit.JavascriptInterface
    public void saveBlobPdf(String blobContent) {

        try {
            byte[] decodedBytes = android.util.Base64.decode(blobContent.split(",")[1], android.util.Base64.DEFAULT);
            File outputFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), filename);
            FileOutputStream outputStream = new FileOutputStream(outputFile);
            outputStream.write(decodedBytes);
            outputStream.close();
            Toast.makeText(this, "PDF Downloaded", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void showToast(String message) {
        // Display a toast with the JavaScript alert, confirmation, or prompt message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // Permission granted, retry the download
            webView.reload();
        } else {
            Toast.makeText(this, "Permission denied. Cannot download file.", Toast.LENGTH_SHORT).show();
        }
    }
}
